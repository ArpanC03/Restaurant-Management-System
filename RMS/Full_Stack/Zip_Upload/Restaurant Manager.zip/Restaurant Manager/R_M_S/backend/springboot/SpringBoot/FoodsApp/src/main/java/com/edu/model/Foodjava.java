package com.edu.model;

public class Foodjava {

}
